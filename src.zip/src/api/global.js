const baseURL = 'http://healthtest.alink365.cn'

// http://healthtest.alink365.cn

export default {
    baseURL
}