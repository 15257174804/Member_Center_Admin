<template>
  <div class="power">
    <div class="title clearfix">
      <span>权限管理</span>
      <router-link to="/adfloor">
        <el-button type="success">
          <i class="el-icon-circle-plus-outline"></i>
          新建
        </el-button>
      </router-link>
    </div>

  </div>
</template>

<script>
export default {
  name:"power",
  data(){
    return {

    }
  },
  methods:{

  }
}
</script>

<style>

</style>